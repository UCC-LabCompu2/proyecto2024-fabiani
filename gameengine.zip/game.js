import { Color, ColorRect, $, Label, createGame, Vector2D, Camera } from "./flopyjs/main.js"
import Player from "./js/player.js"

// Inicializando el juego
const game = createGame('screen');

// Creando el jugador
const player = new Player();
const camera = new Camera();

player.position = new Vector2D(200, 200);
player.addChild(camera)

game.addChild(player);
game.root.setCamera(camera);

const block = new ColorRect(Color.red, new Vector2D(50, 50));
block.position.set(100, 100);
game.addChild(block);

// Detalle de los fps
let fps = new Label("FPS: 0", "Pixelify Sans", "white", 16, 100, 50, 200, 20);
game.addChild(fps);

window.setInterval(() => {
    fps.text = "FPS: " + game.fps;
})

// Interactividad del menu
let startButton = $('#start');
let menu = $('#menu');
let name = $('#name');

startButton.on('click', startGame);

function startGame() {
    if (name.value == "") {
        name.addClass("error");
        return;
    }

    game.run();
    game.pause = false
    name.removeClass("error");
    menu.hide();
    player.getChild(1).text = name.value;

    startButton.value = "Continue";
    $("#title").html = "Pause";
}

$('#pause').on('click', () => {
    menu.show(); 
    game.pause = true;
});
