import { Renderer, Color, Label, Node2D, Vector2D, Sprite, Input } from "../flopyjs/main.js";
import { Joystick } from "./joystick.js"

// Agrega otras teclas como entrada
const CONFIG = {
    inputMap: {
        left: ["ArrowLeft", "KeyA"],
        right: ["ArrowRight", "KeyD"],
        up: ["ArrowUp", "KeyW"],
        down: ["ArrowDown", "KeyS"]
    }
};

// Configura el mapa de entradas
Input.setKeyMap(CONFIG.inputMap);

/**
 * Clase Player que hereda Node2D
 * @extends Node2D
 */
class Player extends Node2D  {
    constructor() {
        super();
        this.joystick = new Joystick('joystick-container')
        this.speed = 0.5;
        this.playerName = "";
        this.velocity = new Vector2D();
        // Crea y añade como hijo una imagen al jugador para que se renderice
        let spr = new Sprite("./assets/sprites/player.png");
        spr.name = "spr";
        spr.anchor.set(0.5, 0.5);
        this.addChild(spr)
        let nameLabel = new Label(this.playerName, "Pixelify Sans", "white", 18);
        nameLabel.anchor.set(0.5, 0.5);
        nameLabel.name = "nameLabel";
        nameLabel.posX = 15
        nameLabel.posY = -10
        this.addChild(nameLabel)
    }

    update(delta) {
        // Movimiento del jugador
        this.velocity.x = Input.isPressed('right') - Input.isPressed('left');
        this.velocity.y = Input.isPressed('down') - Input.isPressed('up');
        if (this.joystick.dragging) {
            this.velocity.x = this.joystick.relativeX
            this.velocity.y = this.joystick.relativeY
        } else {
            this.velocity.normalize()
        }
        

        this.velocity.mult(this.speed * delta);
        if (!this.velocity.isEquals(0, 0)) this.getChild(0).rotation = this.velocity.angle() + Math.PI * (3 / 2);
        this.move(this.velocity);
        this.position.clamp(0, 0, this.getRoot().width - this.getChild(0).width, this.getRoot().height - this.getChild(0).height);
    }

    input_move(vel) {
        this.move(vel.mult(this.speed));
    }

    move(vel) {
        this.position.add(vel);
    }
}

// Export the classes
export { Player };
export default Player
